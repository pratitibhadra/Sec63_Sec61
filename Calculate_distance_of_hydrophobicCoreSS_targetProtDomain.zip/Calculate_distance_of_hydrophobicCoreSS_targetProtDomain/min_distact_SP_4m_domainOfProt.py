import mdtraj as md
from itertools import product
import csv
import sys
import numpy as np

# install mdtraj
# usgae: python3 min_distact_SP_4m_domainOfProt.py HCPY
# HCPY.pdb have all docking confromation from docking simulations

traj = md.load(sys.argv[1]+".pdb")


if sys.argv[1] == 'HCPY':
	group_1 = [ 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477] # HCPY #hydrophobic region of CPY signal peptide

group_2 = [ 289, 290, 291, 292, 293, 294, 295, 296] #TM7n

pairs = list(product(group_1, group_2))


cont = md.compute_contacts(traj, pairs)


data = [[0 for x in range(len(group_1))] for y in range(30)] 
part_len = len(group_2)

for i in range(0,len(cont[0])): #len(cont[0])
	j = -1
	for indx in range(0,len(group_1)*part_len,part_len):
		#print(np.amin(cont[0][i][indx:indx+part_len]))
		j=j+1
		data[i][j]=round(np.amin(cont[0][i][indx:indx+part_len]),3)
               	
		

outfile = "nTM7_"+sys.argv[1]+".csv"
with open(outfile, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)

# Out file
# row denote number of conformation of HCPY.pdb (input file)
# colunm denote residues of hydrophobic region of CPY signal peptide  (HPCY represnet hydrophobic part of signal peptide CPY)
# value in matrix represent the minimum distance of between the particular residue of SP and the region of target protein.
