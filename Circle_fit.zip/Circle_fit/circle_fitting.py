import circle_fit as cf
from csv import reader
import pandas as pd
import sys

# usage python3 circle_fitting.py XY_cord_Tth_frame.csv
# XY coordinate (X:1st column, Y:2nd colunm) of atoms (row) of a particula time frames are save 

filename = sys.argv[1]
data = pd.read_csv(filename)
data.columns = ["X", "Y"]
X_cord = list(data.X)
Y_cord = list(data.Y)

res = [(X_cord[i], Y_cord[i] % len(X_cord)) for i in range(len(X_cord))]
#print(res)


xc,yc,r,_ = cf.least_squares_circle(res)

#radius of the fitted circle
print(r)

#center of the circle
#print(xc)
#print(yc)
