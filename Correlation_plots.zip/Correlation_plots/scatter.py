import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
import scipy.stats

# usage: python3 scatter.py

sns.set(font_scale=1.3) 
sns.set_style("whitegrid")
datafile = pd.read_csv('one_thetaTM2_dTM2TM10.csv', delimiter=',') # change file name as per needed
ax = sns.scatterplot(x="Distance between TM10-TM2 (nm)", y="Angle between TM2 and parallel vector of lipid payer (angle)", hue="Replica", style="State",data=datafile)
#ax = sns.catplot(x="Replica", y="Percentage of residue adopt b-sheet", data=datafile, col="State", kind="box")
#ax = sns.swarmplot(x="Replica", y="Percentage of residue adopt b-sheet", data=datafile, color=".25")
#ax = sns.violinplot(x="Replica", y="Percentage of residue adopt b-sheet", hue="State", data=datafile, inner="quartile", split=True, scale_hue=False)

#h,l = ax.axes[0].get_legend_handles_labels()
#ax.axes[0].legend_.remove()
#ax.fig.legend(h,l, ncol=2)

l1,=plt.plot(1.96,109.3,'k*',markersize=16,label="6N3Q")
#l2,=plt.plot(1.65,110.1,'ks',markersize=14,label="2WW9")
l3,=plt.plot(1.68,104.1,'k>',markersize=12,label="3J7Q")
l4,=plt.plot(1.83,109.3,'r>',markersize=12,label="3JC2")

plt.ylabel(r"$\theta_{TM2}$ (degree)")
plt.xlabel(r" d$_{nTM2-nTM10}$ (nm)")

x = datafile.values[:,2]
y = datafile.values[:,3]
pcc=scipy.stats.pearsonr(x, y)[0] 
0.82
print(pcc)
#State,Replica,Angle with normal of lipid layer (degree),Angle with parallel vector of lipif layer
plt.legend(loc='best', fontsize=9)
plt.tight_layout()
#plt.legend()
plt.show()
