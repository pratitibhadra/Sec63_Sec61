import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set(font_scale=1.3)  
sns.set_style('whitegrid')

# Create a dataframe from csv
#datafile = pd.read_csv('./PRP/PRP_l181.csv', delimiter=',')
datafile = pd.read_csv('sec61.csv', delimiter=',')
R1_ang=datafile.values[:,1]
R2_ang=datafile.values[:,2]
R3_ang=datafile.values[:,3]
R4_ang=datafile.values[:,4]
R5_ang=datafile.values[:,5]
datafile1 = pd.read_csv('sec63.csv', delimiter=',')
R1_ang1=datafile1.values[:,1]
R2_ang1=datafile1.values[:,2]
R3_ang1=datafile1.values[:,3]
R4_ang1=datafile1.values[:,4]
R5_ang1=datafile1.values[:,5]
avg_sec61=np.mean(np.array([ R1_ang, R2_ang, R3_ang, R4_ang, R5_ang ]), axis=0)
avg_sec63=np.mean(np.array([ R1_ang1, R2_ang1, R3_ang1, R4_ang1, R5_ang1 ]), axis=0)
#sns.lineplot(x="time",y="R1", data=datafile);
s1=sns.distplot(R1_ang,hist=False,color="red",label="free-R1")
s2=sns.distplot(R2_ang,hist=False,color="blue",label="free-R2")
s3=sns.distplot(R3_ang,hist=False,color="green",label="free-R3")
s4=sns.distplot(R4_ang,hist=False,color="cyan",label="free-R4")
s5=sns.distplot(R5_ang,hist=False,color="magenta",label="free-R5")
s6=sns.distplot(avg_sec61,hist=False,color="grey",label="free-average")
s7=sns.distplot(R1_ang1,hist=False,color="red",label="Sec63-B-R1",kde_kws={'linestyle':'--'})
s8=sns.distplot(R2_ang1,hist=False,color="blue",label="Sec63-B-R2",kde_kws={'linestyle':'--'})
s9=sns.distplot(R3_ang1,hist=False,color="green",label="Sec63-B-R3",kde_kws={'linestyle':'--'})
s10=sns.distplot(R4_ang1,hist=False,color="cyan",label="Sec63-B-R4",kde_kws={'linestyle':'--'})
s11=sns.distplot(R5_ang1,hist=False,color="magenta",label="Sec63-B-R5",kde_kws={'linestyle':'--'})
s12=sns.distplot(avg_sec63,hist=False,color="grey",label="Sec63-B-average",kde_kws={'linestyle':'--'})
l1,=plt.plot(1.96,0.0,'k*',markersize=18,label="6N3Q")
#l2,=plt.plot(1.65,0.0,'ks',markersize=14,label="2WW9")
l3,=plt.plot(1.68,0.0,'k>',markersize=14,label="3J7Q")
l4,=plt.plot(1.83,0.0,'r>',markersize=14,label="3JC2")

plt.ylabel("Density")
plt.xlabel(r"$d_{nTM2-nTM10}$ (nm)")
plt.tight_layout()
plt.legend(loc='upper left', fontsize=9)
plt.show()
