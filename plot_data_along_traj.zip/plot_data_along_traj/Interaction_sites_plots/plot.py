import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

#usgae: python3 plot.py


# Create a dataframe from csv
datafile = pd.read_csv('IS4_matplt.csv', delimiter=',') # change the inpute file names ISi_matplt.csv i =1,2,3,4
time=datafile.values[:,0]
R1=datafile.values[:,1]
R2=datafile.values[:,2]
R3=datafile.values[:,3]
R4=datafile.values[:,4]
R5=datafile.values[:,5]
#avg_sec61=np.mean(np.array([ R1_ang, R2_ang, R3_ang ]), axis=0)
plt.plot(time,R1,color='red',label="Sec63-B-R1",linestyle=':')
plt.plot(time,R2,color='blue',label="Sec63-B-R2",linestyle=':')
plt.plot(time,R3,color='green',label="Sec63-B-R3",linestyle=':')
plt.plot(time,R4,color='cyan',label="Sec63-B-R4",linestyle=':')
plt.plot(time,R5,color='magenta',label="Sec63-B-R5",linestyle=':')
#plt.plot([0,1000],[0.68, 0.68],color='black',label="EM-structure") # IS1
#plt.plot([0,1000],[1.12, 1.12],color='black',label="EM-structure") #IS2
#plt.plot([0,1000],[0.4, 0.4],color='black',label="EM-structure") #IS3
plt.plot([0,1000],[1.34, 1.34],color='black',label="EM-structure") #IS4
plt.ylabel("Distance (nm)",fontsize=18)
plt.xlabel("Time (ns)",fontsize=18)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
#plt.ylim(1.2,1.55)
plt.legend(loc='lower left')
plt.text(500, 1.49, 'IS4', fontsize=22)
plt.tight_layout()
plt.show()
