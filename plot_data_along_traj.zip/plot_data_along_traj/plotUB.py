import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

# Create a dataframe from csv
#datafile = pd.read_csv('./PRP/PRP_l181.csv', delimiter=',')
datafile = pd.read_csv('Rg.csv', delimiter=',')
time=datafile.values[:,0]
UR1=datafile.values[:,1]
UR2=datafile.values[:,2]
UR3=datafile.values[:,3]
UR4 = datafile.values[:,4]
UR5 = datafile.values[:,5]
R1 = datafile.values[:,6]
R2 = datafile.values[:,7]
R3 = datafile.values[:,8]
R4 = datafile.values[:,9]
R5 = datafile.values[:,10]
#avg_sec61=np.mean(np.array([ R1_ang, R2_ang, R3_ang ]), axis=0)
p1=plt.plot(time,UR1,color='red',label="free-R1")
p2=plt.plot(time,UR2,color='blue',label="free-R2")
p3=plt.plot(time,UR3,color='green',label="free-R3")
p4=plt.plot(time,UR4,color='cyan',label="free-R4")
p5=plt.plot(time,UR5,color='magenta',label="free-R5")
avg_sec61=np.mean(np.array([ UR1, UR2, UR3, UR4, UR5 ]), axis=0)
p11=plt.plot(time,avg_sec61,color='black',label="free-avg")
print(avg_sec61[499])
#p6=plt.plot(time,R1,color='red',label="B-R1",linestyle=":")
#p7=plt.plot(time,R2,color='blue',label="B-R2",linestyle=":")
#p8=plt.plot(time,R3,color='green',label="B-R3",linestyle=":")
#p9=plt.plot(time,R4,color='cyan',label="B-R4",linestyle=":")
avg_sec63=np.mean(np.array([ R1, R2, R3, R4, R5]), axis=0)
#p10=plt.plot(time,avg_sec63,color='black',label="B-avg",linestyle=":")
#p4=plt.plot([0,1000],[0.68, 0.68],color='black',label="EM-structure")
#sns.distplot(R1_ang,hist=False,color="red",label="Unbounded R1")
#sns.distplot(R2_ang,hist=False,color="blue",label="Unbounded R2")
#sns.distplot(R3_ang,hist=False,color="green",label="Unbounded R3")
#sns.distplot(avg_sec61,hist=False,color="black",label="Unbounded average")
#sns.distplot(R1_ang1,hist=False,color="red",label="Bounded R1",kde_kws={'linestyle':'--'})
#sns.distplot(R2_ang1,hist=False,color="blue",label="Bounded R2",kde_kws={'linestyle':'--'})
#sns.distplot(R3_ang1,hist=False,color="green",label="Bounded R3",kde_kws={'linestyle':'--'})
#sns.distplot(avg_sec63,hist=False,color="black",label="Bounded average",kde_kws={'linestyle':'--'})
print(avg_sec63[499])
plt.ylabel("Radius of gyration (nm)",fontsize=18)
plt.xlabel("Time (ns)",fontsize=18)
plt.ylim(2.4,2.7)
plt.xlim(0,1000)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(loc='lower left',fontsize="x-large")
plt.tight_layout()
plt.show()
