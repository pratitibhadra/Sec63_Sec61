import math
import numpy as np
import sys

# usage: python3 Angle_wrt_LBplane.py helix_axis
# helix_axis file contains vector of the helix_axis in form x,y,z

surf_normXY = [0, 0, 1]

ca_x={}
ca_y={}
ca_z={}



def dotproduct(v1, v2):
  return sum((a*b) for a, b in zip(v1, v2))

def length(v):
  return math.sqrt(dotproduct(v, v))

def angle(v1, v2):
  return math.acos(dotproduct(v1, v2) / (length(v1) * length(v2)))

file1=sys.argv[1]

with open(file1) as f:
    f=[x.strip() for x in f if x.strip()]
    data=[tuple(map(float,x.split(","))) for x in f[0:]]
    plg61_x=[x[0] for x in data]
    plg61_y=[x[1] for x in data]
    plg61_z=[x[2] for x in data]



for i in range(500):
    v_plug=[plg61_x[i],plg61_y[i],plg61_z[i]]
    v=[plg61_x[i],plg61_y[i],0] 
    ang = 180-57.29*angle(surf_XY,v_plug)
    print(round(ang,2))
    
  
